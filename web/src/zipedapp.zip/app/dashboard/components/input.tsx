"use client";

import React, { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useSearchParams } from "next/navigation";

type UserFromDB = {
  id: number;
  nama: string;
  username: string;
  email: string;
  telepon: string;
  jenis_kelamin: string;
  lembaga: string;
  tingkatan: string;
};

type FormData = {
  tempat_lahir: string;
  tanggal_lahir: string;
  alamat: string;
  agama: string;
  anak_ke?: number;
  jumlah_saudara?: number;
  golongan_darah?: string;
  penyakit?: string;
  nama_ayah: string;
  nama_ibu: string;
  pekerjaan_ayah: string;
  pekerjaan_ibu: string;
  no_telp_ortu: string;
  alamat_ortu: string;
  asal_sekolah: string;
  tahun_lulus?: number;
};

export default function InputBio({ onComplete }: Props) {
  const { data: session, status } = useSession();
  const searchParams = useSearchParams();
  const username = searchParams.get("user"); // ambil ?user=user2 dari URL

  const [userData, setUserData] = useState<UserFromDB | null>(null);
  
  const [formData, setFormData] = useState<FormData>({
    tempat_lahir: "",
    tanggal_lahir: "",
    alamat: "",
    agama: "",
    anak_ke: undefined,
    jumlah_saudara: undefined,
    golongan_darah: "",
    penyakit: "",
    nama_ayah: "",
    nama_ibu: "",
    pekerjaan_ayah: "",
    pekerjaan_ibu: "",
    no_telp_ortu: "",
    alamat_ortu: "",
    asal_sekolah: "",
    tahun_lulus: undefined,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Ambil userId dari session
  const userId = (session as any)?.user?.id ?? null;

  useEffect(() => {
    if (!username) return;
  
    const fetchUserData = async () => {
      try {
        console.log("Fetching user:", username); // debug
        const res = await fetch(`/api/user?username=${username}`);
        if (!res.ok) throw new Error(`Gagal ambil data user (${res.status})`);
  
        const data: UserFromDB = await res.json();
        setUserData(data);
      } catch (err) {
        console.error("Fetch user error:", err);
        setError("Gagal ambil data user");
        setUserData(null);
      }
    };
  
    fetchUserData();
  }, [username]);

  if (!userData) return <p>{error || "Loading data user..."}</p>;

  return (
    <form className="flex flex-col gap-4">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex flex-col w-full md:w-1/2">
          <label>Lembaga</label>
          <input value={userData.lembaga} readOnly className="border px-3 py-2 bg-gray-100 cursor-not-allowed" />
        </div>
        <div className="flex flex-col w-full md:w-1/2">
          <label>Tingkatan</label>
          <input value={userData.tingkatan} readOnly className="border px-3 py-2 bg-gray-100 cursor-not-allowed" />
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex flex-col w-full md:w-3/4">
          <label>Nama</label>
          <input value={userData.nama} readOnly className="border px-3 py-2 bg-gray-100 cursor-not-allowed" />
        </div>
        <div className="flex flex-col w-full md:w-1/4">
          <label>Jenis Kelamin</label>
          <input value={userData.jenis_kelamin} readOnly className="border px-3 py-2 bg-gray-100 cursor-not-allowed" />
        </div>
      </div>
    </form>
  );
}
